import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GridPerformanceSampleComponent } from './grid-performance-sample.component';

describe('GridPerformanceSampleComponent', () => {
  let component: GridPerformanceSampleComponent;
  let fixture: ComponentFixture<GridPerformanceSampleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GridPerformanceSampleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GridPerformanceSampleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
